﻿// SysmonETWexporter/Program.cs
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Session;
using OpenTelemetry;
using OpenTelemetry.Exporter;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace SysmonETWexporter
{
    internal class Program
    {
        private const string SysmonProvider = "Microsoft-Windows-Sysmon";
        private const ulong SysmonKeywords = ulong.MaxValue;
        private const TraceEventLevel SysmonLevel = TraceEventLevel.Informational;
        private const string SessionName = "SysmonETW";

        /* ── OpenTelemetry 설정 ─────────────────────────────────────────────── */
        private static readonly TracerProvider Otel =
            Sdk.CreateTracerProviderBuilder()
               .SetResourceBuilder(ResourceBuilder.CreateDefault()
                   .AddService("sysmon-agent"))
               .AddSource("sysmon.etw")
               .AddOtlpExporter(o =>
               {
                   /* ← PID 집계기(router)가 수신하는 주소로 변경 */
                   o.Endpoint = new Uri("http://localhost:4319");
                   o.Protocol = OtlpExportProtocol.Grpc;
               })
               .Build();

        private static readonly ActivitySource Src = new("sysmon.etw");
        private static readonly ConcurrentDictionary<int, Activity> Roots = new();

        private static void Main()
        {
            /* 관리자 권한 확인 */
            if (!(TraceEventSession.IsElevated() ?? false)) return;

            using var session = new TraceEventSession(SessionName) { StopOnDispose = true };
            session.EnableProvider(SysmonProvider, SysmonLevel, SysmonKeywords);

            session.Source.AllEvents += HandleEvent;   // 정적 ETW 이벤트
            session.Source.Dynamic.All += HandleEvent;   // 동적 ETW 이벤트

            var etwThread = new Thread(() => session.Source.Process()) { IsBackground = true };
            etwThread.Start();

            Console.WriteLine("Sysmon ETW exporter is running …  <Enter> to quit");
            Console.ReadLine();

            session.Dispose();
            Otel.Dispose();
            etwThread.Join();
        }

        /* ──────────────────────────────────────────────────────────────────── */
        private static void HandleEvent(TraceEvent ev)
        {
            /* ① Payload에서 실제 ProcessId / ParentProcessId 추출  */
            int realPid = TryGetPayloadInt(ev, "ProcessId") ?? ev.ProcessID;
            int parentPid = TryGetPayloadInt(ev, "ParentProcessId") ?? 0;

            /* ② 루트 Activity는 ‘실제 PID’ 기준으로 관리 */
            if (!Roots.TryGetValue(realPid, out var root))
            {
                root = Src.StartActivity($"process:{realPid}", ActivityKind.Internal);
                if (root != null) Roots[realPid] = root;
            }
            if (root == null) return;

            /* ③ 이벤트 단위 자식 Activity 생성 */
            using var child = Src.StartActivity($"evt:{(int)ev.ID}, pid:{(int)realPid}, ppid:{(int)parentPid}", ActivityKind.Internal,
                                                parentContext: root.Context);
            if (child == null) return;

            AddTags(child, ev, realPid, parentPid);

            /* ── 디버그 콘솔 ─────────────────────────────────────────── */
            Console.WriteLine($"PID={realPid}  EventID={(int)ev.ID}  Task={ev.Task}  Opcode={ev.Opcode}");
            if (ev.PayloadNames is { Length: > 0 })
            {
                foreach (var n in ev.PayloadNames)
                {
                    try { Console.WriteLine($"    {n} : {ev.PayloadByName(n)}"); } catch { }
                }
            }
            Console.WriteLine();

            /* ④ 프로세스 종료(ID 5) 또는 Sysmon 서비스 종료(ID 255) → 루트 정리 */
            int eid = (int)ev.ID;
            if (eid == 5 || eid == 255)
            {
                root.Stop();
                Roots.TryRemove(realPid, out _);
            }
        }

        /* ──────────────────────────────────────────────────────────────────── */
        private static void AddTags(Activity act, TraceEvent ev, int pid, int ppid)
        {
            void T(string k, object? v) { if (v != null) act.SetTag(k, v); }

            /* 기본 태그 */
            T("sysmon.pid", pid);
            if (ppid != 0) T("sysmon.ppid", ppid);
            T("sysmon.event_id", (int)ev.ID);
            T("sysmon.task", ev.Task);
            T("sysmon.opcode", ev.Opcode);
            T("provider_guid", ev.ProviderGuid);

            /* TraceEvent의 public 속성 전체 태그화 */
            foreach (var p in ev.GetType()
                                .GetProperties(BindingFlags.Public | BindingFlags.Instance)
                                .Where(p => p.GetIndexParameters().Length == 0))
            {
                try { T(p.Name, p.GetValue(ev)); } catch { }
            }

            /* Payload 필드 태그화 */
            if (ev.PayloadNames is { Length: > 0 })
            {
                foreach (var n in ev.PayloadNames)
                {
                    try { T(n, ev.PayloadByName(n)); } catch { }
                }
            }
        }

        /* ──────────────────────────────────────────────────────────────────── */
        private static int? TryGetPayloadInt(TraceEvent ev, string field)
        {
            if (ev.PayloadNames?.Contains(field) == true)
            {
                try
                {
                    object? val = ev.PayloadByName(field);
                    return val switch
                    {
                        int i => i,
                        long l => (int)l,
                        string s when int.TryParse(s, out int parsed) => parsed,
                        _ => null
                    };
                }
                catch { /* ignore */ }
            }
            return null;
        }
    }
}